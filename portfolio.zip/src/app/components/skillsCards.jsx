"use client"
import React , {useState,useEffect} from "react";
import SkillProgress from "./SkillProgress";
export const SkillsCards =()=>{
    const skills = [
        { skill: "React", percentage: 85, color: "#01EEFF" },
        { skill: "Next.js", percentage: 80, color: "#01EEFF" },
        { skill: "UI/UX Design", percentage: 90, color: "#01EEFF" },
      ];
    
    return(

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
      {skills.map((skill, index) => (
        <SkillProgress
          key={index}
          skill={skill.skill}
          percentage={skill.percentage}
          color={skill.color}
        />
      ))}
    </div>

    )
}
