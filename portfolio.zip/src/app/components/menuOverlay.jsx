import React from "react";
import { NavLinks } from "./navLinks";
export function MenuOverlay ({links,hideMenu}) {
    return(
        <div>
            <ul className="flex flex-col py-4 items-center">
            <li>
                <button onClick={hideMenu}>
                <NavLinks title="about" path={"#about"}/>
                </button>
              
            </li>
            <li>
            <button onClick={hideMenu}>
            <NavLinks title="services" path={"#services"}/>
            </button>
            </li>
            <li>
            <button onClick={hideMenu}>
            <NavLinks title="contact" path={"#contact"}/>
            </button>
            </li>
            </ul>
        </div>
    )
}