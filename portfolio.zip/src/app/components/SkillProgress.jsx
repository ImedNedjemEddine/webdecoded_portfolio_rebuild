import React from "react";
import { CircularProgressbar, buildStyles } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";

const SkillProgress = ({ skill, percentage, color }) => {
  return (
    <div className="flex flex-col items-center">
      <div style={{ width: "120px", height: "120px" }}>
        <CircularProgressbar
          value={percentage}
          text={`${percentage}%`}
          styles={buildStyles({
            textColor: color,
            pathColor: color,
            trailColor: "#d6d6d6",
          })}
        />
      </div>
      <p className="mt-4 text-center text-lg text-[#01EEFF] font-semibold">{skill}</p>
    </div>
  );
};

export default SkillProgress;
